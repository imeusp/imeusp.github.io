
#include "common.h"
#include "image.h"
#include "cimage.h"
#include "adjacency.h"
#include "queue.h"
#include "gpqueue_by_Falcao.h"
#include "morphology.h"

/* Devolve o representante de p */
int Find(Image *R, int p){
  if(R->val[p] == p)
    return p;
  else{
    R->val[p] = Find(R, R->val[p]);
    return R->val[p];
  }
}


/*Removes all background connected components from the stack
of binary images of I whose area (number of pixels) is less than 
a threshold and outputs a simplified image.*/
Image *AreaClosing(AdjRel *A, Image *I, int T){
  Image *J,*V;
  Image *Ar; /* Areas para os representantes */
  Image *R; /* Imagem de representantes */
  Image *P; /* Imagem de predecessores */
  GQueue *Q;
  int p,q,n,Imax,rp,rq,tmp;
  int xp,yp,xq,yq,i;
  //Image *teste;

  Imax = MaximumValue(I);
  n  = I->ncols*I->nrows;
  V  = CreateImage(I->ncols, I->nrows);
  J  = CreateImage(I->ncols, I->nrows);
  Ar = CreateImage(I->ncols, I->nrows);
  R  = CreateImage(I->ncols, I->nrows);
  P  = CreateImage(I->ncols, I->nrows);

  /*teste  = CreateImage(I->ncols, I->nrows);*/

  Q  = CreateGQueue(Imax+2, n, V->val);
  SetTieBreak(Q, LIFOBREAK);

  for(p = 0; p < n; p++){
    P->val[p] = NIL;
    V->val[p] = I->val[p] + 1;
    R->val[p] = p;
    Ar->val[p] = 0;
    J->val[p] = I->val[p];
    InsertGQueue(&Q, p);
  }

  while(!EmptyGQueue(Q)){
    p = RemoveGQueue(Q);
    rp = Find(R, p);

    if(Ar->val[rp] <= T && J->val[rp] < I->val[p])
      J->val[rp] = I->val[p];

    Ar->val[rp]++;
    xp = p%I->ncols;
    yp = p/I->ncols;
    for(i = 1; i < A->n; i++){
      xq = xp + A->dx[i];
      yq = yp + A->dy[i];
      if(ValidPixel(I, xq, yq)){
	q = xq + yq*I->ncols;
	/*
	if(V->val[q] > V->val[p]){
	*/
	if(Q->L.elem[q].color != BLACK){
	  tmp = MAX(V->val[p], I->val[q]);
	  if(tmp <= V->val[q]){
	    RemoveGQueueElem(Q, q);
	    V->val[q] = tmp;
	    P->val[q] = p;
	    R->val[q] = rp;
	    InsertGQueue(&Q, q);
	  }
	}
	else{/* if(Q->L.elem[q].color != GRAY){*/
	  rq = Find(R, q);
	  if(rp != rq){
	    if(Ar->val[rq] <= T && J->val[rq] < I->val[p])
	      J->val[rq] = I->val[p];
	    if(Ar->val[rp] < Ar->val[rq]){
	      tmp = rp;
	      rp = rq;
	      rq = tmp;
	    }
	    R->val[rq] = rp;
	    Ar->val[rp] += Ar->val[rq];
	    /*
	    if(P->val[p] == NIL && P->val[q] == NIL)
	      P->val[rq] = rp;
	    */
	  }
	}
      }
    }
  }
  ResetGQueue(Q);
  SetRemovalPolicy(Q, MAXVALUE);

  for(p = 0; p < n; p++){
    V->val[p] = J->val[p];
    if(P->val[p] == NIL){
      InsertGQueue(&Q, p);
      //teste->val[p] = 1;
    }
  }
  while(!EmptyGQueue(Q)){
    p = RemoveGQueue(Q);    
    xp = p%I->ncols;
    yp = p/I->ncols;
    for(i = 1; i < A->n; i++){
      xq = xp + A->dx[i];
      yq = yp + A->dy[i];
      if(ValidPixel(I, xq, yq)){
	q = xq + yq*I->ncols;
	if(V->val[p] > V->val[q]){
	  if(Q->L.elem[q].color == GRAY)
	    RemoveGQueueElem(Q, q);
	  V->val[q] = V->val[p];
	  InsertGQueue(&Q, q);
	}
      }
    }
  }

  //WriteImage(teste, "teste.pgm");

  DestroyImage(&J);
  DestroyImage(&R);
  DestroyImage(&P);
  DestroyImage(&Ar);
  DestroyGQueue(&Q);
  return V;
}



int main(){
  Image *I,*AC;
  AdjRel *A;
  int T;

  A = Circular(1.0);
  printf("Entre com o valor de T: ");
  scanf("%d",&T);
  I = ReadImage("./dat/cheese.pgm");

  AC = AreaClosing(A, I, T);

  WriteImage(AC, "AC.pgm");

  DestroyImage(&I);
  DestroyImage(&AC);
  DestroyAdjRel(&A);

  return 0;
}

