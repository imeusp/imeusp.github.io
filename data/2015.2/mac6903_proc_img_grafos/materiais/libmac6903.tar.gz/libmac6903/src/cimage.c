
#include "cimage.h"

CImage *CreateCImage(int ncols, int nrows){
  CImage *cimg=NULL;
  int i;

  cimg = (CImage *) calloc(1, sizeof(CImage));
  for (i=0; i < 3; i++)
    cimg->C[i] = CreateImage(ncols,nrows);
  return(cimg);
}


void    DestroyCImage(CImage **cimg){
  CImage *tmp;
  int i;

  tmp = *cimg;
  if (tmp != NULL) {
    for (i=0; i < 3; i++)
      DestroyImage(&(tmp->C[i]));
    free(tmp);
    *cimg = NULL;
  }
}


CImage *ReadCImage(char *filename){
  CImage *cimg=NULL;
  FILE *fp=NULL;
  char type[10];
  int  t,i,ncols,nrows,n;
  char z[256];

  fp = fopen(filename,"rb");
  if (fp == NULL){
    fprintf(stderr,"Cannot open %s\n",filename);
    exit(-1);
  }
  fscanf(fp,"%s\n",type);
  if((strcmp(type,"P6")==0)){
    NCFgets(z,255,fp);
    t = sscanf(z,"%d %d\n",&ncols,&nrows);
    if(t == EOF || t < 2){
      NCFgets(z,255,fp);
      sscanf(z,"%d %d\n",&ncols,&nrows);
    }
    n = ncols*nrows;
    NCFgets(z,255,fp);
    sscanf(z,"%d\n",&i);
    cimg = CreateCImage(ncols,nrows);
    for (i=0; i < n; i++){
      cimg->C[0]->val[i] = fgetc(fp);
      cimg->C[1]->val[i] = fgetc(fp);
      cimg->C[2]->val[i] = fgetc(fp);
    }
    fclose(fp);
  }else{
    fprintf(stderr,"Input image must be P6\n");
    exit(-1);
  }

  return(cimg);
}


void    WriteCImage(CImage *cimg, char *filename){
  FILE *fp;
  int i,n;

  fp = fopen(filename,"w");
  fprintf(fp,"P6\n");
  fprintf(fp,"%d %d\n",cimg->C[0]->ncols,cimg->C[0]->nrows);
  fprintf(fp,"255\n");
  n = cimg->C[0]->ncols*cimg->C[0]->nrows;
  for (i=0; i < n; i++) {
    fputc(cimg->C[0]->val[i],fp);
    fputc(cimg->C[1]->val[i],fp);
    fputc(cimg->C[2]->val[i],fp);
  }
  fclose(fp);
}


CImage *CloneCImage(CImage *cimg){
  CImage *imgc;
  int i;

  imgc = (CImage *) calloc(1,sizeof(CImage));
  if (imgc == NULL){
    Error(MSG1,"CloneCImage");
  }
  for (i=0; i<3; i++)
    imgc->C[i] = CloneImage(cimg->C[i]);
  return imgc;
}


void    SetCImage(CImage *cimg, int r, int g, int b){
  SetImage(cimg->C[0], r);
  SetImage(cimg->C[1], g);
  SetImage(cimg->C[2], b);
}


CImage *ColorizeLabel(Image *label){
  CImage *cimg;
  int n,p,l,Lmax = MaximumValue(label);
  int *R,*G,*B;

  cimg = CreateCImage(label->ncols, label->nrows);
  R = AllocIntArray(Lmax+1);
  G = AllocIntArray(Lmax+1);
  B = AllocIntArray(Lmax+1);
  RandomSeed();
  for(l = 0; l <= Lmax; l++){
    R[l] = RandomInteger(0, 255);
    G[l] = RandomInteger(0, 255);
    B[l] = RandomInteger(0, 255);
  }
  n = label->ncols*label->nrows;
  for(p = 0; p < n; p++){
    l = label->val[p];
    cimg->C[0]->val[p] = R[l];
    cimg->C[1]->val[p] = G[l];
    cimg->C[2]->val[p] = B[l];
  }
  free(R);
  free(G);
  free(B);
  return cimg;
}

