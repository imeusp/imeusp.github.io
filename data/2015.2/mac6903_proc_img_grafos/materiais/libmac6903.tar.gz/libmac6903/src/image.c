
#include "image.h"

Image *CreateImage(int ncols, int nrows){
    Image *img=NULL;

    img = (Image *) calloc(1,sizeof(Image));
    if (img == NULL){
        Error(MSG1,"CreateImage");
    }
    img->val   = AllocIntArray(nrows*ncols);
    img->ncols = ncols;
    img->nrows = nrows;
    return(img);
}


void DestroyImage(Image **img){
    Image *aux;
    aux = *img;
    if (aux != NULL){
        if (aux->val != NULL)   free(aux->val);
        free(aux);
        *img = NULL;
    }
}


Image  *CloneImage(Image *img){
    Image *imgc;

    imgc = CreateImage(img->ncols,img->nrows);
    memcpy(imgc->val,img->val,img->ncols*img->nrows*sizeof(int));
    return(imgc);
}


Image *ReadImage(char *filename){
    FILE *fp=NULL;
    unsigned char *value=NULL;
    char type[10];
    int  i,ncols,nrows,n;
    Image *img=NULL;
    char z[256];

    fp = fopen(filename,"rb");
    if (fp == NULL){
        fprintf(stderr,"Cannot open %s\n",filename);
        exit(-1);
    }
    fscanf(fp,"%s\n",type);
    if ((strcmp(type,"P5")==0)){
        NCFgets(z,255,fp);
        sscanf(z,"%d %d\n",&ncols,&nrows);
        n = ncols*nrows;
        NCFgets(z,255,fp);
        sscanf(z,"%d\n",&i);
	fgetc(fp);
        value = (unsigned char *)calloc(n,sizeof(unsigned char));
        if (value != NULL){
            fread(value,sizeof(unsigned char),n,fp);
        }
        else{
            fprintf(stderr,"Insufficient memory in ReadImage\n");
            exit(-1);
        }
        fclose(fp);
        img = CreateImage(ncols,nrows);
        for (i=0; i < n; i++)
            img->val[i] = (int)value[i];
        free(value);
    }
    else{
        if ((strcmp(type,"P2")==0)){
            NCFgets(z,255,fp);
            sscanf(z,"%d %d\n",&ncols,&nrows);
            n = ncols*nrows;
            NCFgets(z,255,fp);
            sscanf(z,"%d\n",&i);
            img = CreateImage(ncols,nrows);
            for (i=0; i < n; i++)
                fscanf(fp,"%d",&img->val[i]);
            fclose(fp);
        }
        else{
            fprintf(stderr,"Input image must be P2 or P5\n");
            exit(-1);
        }
    }
    return(img);
}


void WriteImage(Image *img,char *filename){
    FILE *fp;
    int i, n, Imax;

    fp = fopen(filename,"wb");
    if (fp == NULL){
        fprintf(stderr,"Cannot open %s\n",filename);
        exit(-1);
    }
    n    = img->ncols*img->nrows;
    if ((Imax=MaximumValue(img))==INT_MAX){
        Warning("Image with infinity values","WriteImage");
        Imax = INT_MIN;
        for (i=0; i < n; i++)
            if ((img->val[i] > Imax)&&(img->val[i]!=INT_MAX))
                Imax = img->val[i];
        fprintf(fp,"P2\n");
        fprintf(fp,"%d %d\n",img->ncols,img->nrows);
        fprintf(fp,"%d\n",Imax+1);
    }
    else{
        fprintf(fp,"P2\n");
        fprintf(fp,"%d %d\n",img->ncols,img->nrows);
        if (Imax==0) Imax++;
        fprintf(fp,"%d\n",Imax);
    }

    for (i=0; i < n; i++){
        if (img->val[i]==INT_MAX)
            fprintf(fp,"%d ",Imax+1);
        else
            fprintf(fp,"%d ",img->val[i]);
        if (((i+1)%17) == 0)
            fprintf(fp,"\n");
    }
    fclose(fp);
}


Image *ConvertToNbits(Image *img, int N){
    Image *imgN;
    int min,max,i,n,Imax;

    imgN = CreateImage(img->ncols,img->nrows);
    n    = img->ncols*img->nrows;
    Imax = (int)(pow(2,N)-1);

    min = INT_MAX;
    max = INT_MIN;
    for (i=0; i < n; i++){
        if ((img->val[i] != INT_MIN)&&(img->val[i] != INT_MAX)){
            if (img->val[i] > max)
                max = img->val[i];
            if (img->val[i] < min)
                min = img->val[i];
        }
    }

    if (min != max)
        for (i=0; i < n; i++){
            if ((img->val[i] != INT_MIN)&&(img->val[i] != INT_MAX)){
                imgN->val[i] = (int)(((float)Imax*(float)(img->val[i] - min))/
                                     (float)(max-min));
            }
            else{
                if (img->val[i]==INT_MIN)
                    imgN->val[i] = 0;
                else
                    imgN->val[i] = Imax;
            }
        }
    return(imgN);
}


int MinimumValue(Image *img){
    int i,min,n;
    n = img->ncols*img->nrows;
    min = img->val[0];
    for (i=1; i < n; i++)
        if (img->val[i] < min)
            min = img->val[i];

    return(min);
}

int MaximumValue(Image *img){
    int i,max,n;
    n = img->ncols*img->nrows;
    max = img->val[0];
    for (i=1; i < n; i++)
        if (img->val[i] > max)
            max = img->val[i];

    return(max);
}


void SetImage(Image *img, int value){
    int i,n;
    n = img->ncols*img->nrows;
    for (i=0; i < n; i++){
        img->val[i] = value;
    }
}


bool ValidPixel(Image *img, int x, int y){
    if ((x >= 0)&&(x < img->ncols)&&
            (y >= 0)&&(y < img->nrows))
        return(true);
    else
        return(false);
}


