
#include "adjacency.h"

AdjRel *CreateAdjRel(int n){
  AdjRel *A=NULL;

  A = (AdjRel *) calloc(1,sizeof(AdjRel));
  if (A != NULL){
    A->dx = AllocIntArray(n);
    A->dy = AllocIntArray(n);
    A->n  = n;
  } else {
    Error(MSG1,"CreateAdjRel");
  }

  return(A);
}


void DestroyAdjRel(AdjRel **A){
  AdjRel *aux;

  aux = *A;
  if (aux != NULL){
    if (aux->dx != NULL) free(aux->dx);
    if (aux->dy != NULL) free(aux->dy);
    free(aux);
    *A = NULL;
  }   
}


AdjRel *CloneAdjRel(AdjRel *A){
  AdjRel *C;
  int i;

  C = CreateAdjRel(A->n);
  for(i=0; i < A->n; i++){
    C->dx[i] = A->dx[i];
    C->dy[i] = A->dy[i];
  }
  return C;
}


AdjRel *Neighborhood_4(){ /* 4-neighborhood */
  AdjRel *A=NULL;
  A = CreateAdjRel(4+1);
  /* place central pixel at first */
  A->dx[0] = 0;  A->dy[0] = 0;  
  A->dx[1] = 1;  A->dy[1] = 0;  /* right */
  A->dx[2] = 0;  A->dy[2] = -1; /* top */
  A->dx[3] = -1; A->dy[3] = 0;  /* left */
  A->dx[4] = 0;  A->dy[4] = 1;  /* bottom */
  return A;
}


AdjRel *Neighborhood_8(){ /* 8-neighborhood */
  AdjRel *A=NULL;
  int i,dx,dy;
  A = CreateAdjRel(8+1);
  /* place central pixel at first */
  A->dx[0] = 0;
  A->dy[0] = 0;
  i = 1;
  for(dy = -1; dy <= 1; dy++){
    for(dx = -1; dx <= 1; dx++){
      if ((dx != 0)||(dy != 0)){
	A->dx[i] = dx;
	A->dy[i] = dy;
	i++;
      }
    }
  }
  return A;
}


AdjRel *Circular(float r){
  AdjRel *A=NULL;
  int i,n,dx,dy,r0,r2;

  n=0;
  r0 = (int)r;
  r2  = (int)(r*r + 0.5);
  for(dy=-r0;dy<=r0;dy++)
    for(dx=-r0;dx<=r0;dx++)
      if(((dx*dx)+(dy*dy)) <= r2)
	n++;
	
  A = CreateAdjRel(n);
  i = 1;
  for(dy=-r0;dy<=r0;dy++)
    for(dx=-r0;dx<=r0;dx++)
      if(((dx*dx)+(dy*dy)) <= r2){
	if ((dx != 0)||(dy != 0)){
	  A->dx[i] = dx;
	  A->dy[i] = dy;
	  i++;
	}
      }

  /* place central pixel at first */
  A->dx[0] = 0;
  A->dy[0] = 0;

  return(A);
}


AdjRel *Box(int ncols, int nrows){
  AdjRel *A=NULL;
  int i,dx,dy;

  if (ncols%2 == 0) ncols++;
  if (nrows%2 == 0) nrows++;

  A = CreateAdjRel(ncols*nrows);
  i=1;
  for(dy=-nrows/2;dy<=nrows/2;dy++){
    for(dx=-ncols/2;dx<=ncols/2;dx++){
      if ((dx != 0)||(dy != 0)){
	A->dx[i] = dx;
	A->dy[i] = dy;
	i++;
      }
    }
  }
  /* place the central pixel at first */
  A->dx[0] = 0;
  A->dy[0] = 0;

  return(A);
}

