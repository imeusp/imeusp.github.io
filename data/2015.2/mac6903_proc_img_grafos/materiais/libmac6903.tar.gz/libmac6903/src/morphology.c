
#include "morphology.h"

Image *Dilate(Image *img, AdjRel *A){
  Image *dil=NULL;
  int p,q,n,max,i,xp,yp,xq,yq;

  n = img->ncols*img->nrows;
  dil = CreateImage(img->ncols, img->nrows);
  for(p = 0; p < n; p++){
    xp = p%img->ncols;
    yp = p/img->ncols;

    max = INT_MIN;
    for(i=0; i < A->n; i++){
      xq = xp + A->dx[i];
      yq = yp + A->dy[i];
      if(ValidPixel(img, xq, yq)){
	q = xq + yq*img->ncols;
	if(img->val[q] > max)
	  max = img->val[q];
      }
    }
    dil->val[p] = max;
  }
  return(dil);
}


Image *Erode(Image *img, AdjRel *A){
  Image *ero=NULL;
  int p,q,n,min,i,xp,yp,xq,yq;

  n = img->ncols*img->nrows;
  ero = CreateImage(img->ncols, img->nrows);
  for(p = 0; p < n; p++){
    xp = p%img->ncols;
    yp = p/img->ncols;

    min = INT_MAX;
    for(i=0; i < A->n; i++){
      xq = xp + A->dx[i];
      yq = yp + A->dy[i];
      if(ValidPixel(img, xq, yq)){
	q = xq + yq*img->ncols;
	if(img->val[q] < min)
	  min = img->val[q];
      }
    }
    ero->val[p] = min;
  }
  return(ero);
}



Image *MorphGrad(Image *img, AdjRel *A){
  Image *dil=NULL,*ero=NULL,*grad=NULL;
  int p,n;
  n = img->ncols*img->nrows;
  grad = CreateImage(img->ncols, img->nrows);
  dil  = Dilate(img,A);
  ero  = Erode(img,A);
  /*grad = Diff(dil,ero);*/
  for(p = 0; p < n; p++){
    grad->val[p] = dil->val[p] -  ero->val[p];
  }
  DestroyImage(&dil);
  DestroyImage(&ero);

  return(grad);
}


