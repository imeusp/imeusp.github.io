
#include "queue.h"


Queue *CreateQueue(int nbuckets){
  Queue *Q;
  
  Q = (Queue *) malloc(sizeof(Queue));
  if(Q==NULL) Error((char *)MSG1,
		    (char *)"CreateQueue");
  
  Q->nbuckets = nbuckets;
  Q->nadded = 0;
  Q->put = Q->get = 0;
  Q->data = AllocIntArray(nbuckets);
  return Q;
}


void    DestroyQueue(Queue **Q){
  Queue *aux;
  aux = *Q;
  if(aux!=NULL){
    if(aux->data!=NULL) 
      free(aux->data);
    free(aux);
    *Q = NULL;
  }  
}


void    PushQueue(Queue *Q, int p){
  if(!IsFullQueue(Q)){
    Q->nadded++;
    Q->data[Q->put] = p;
    Q->put = (Q->put + 1) % Q->nbuckets;
  }
}


/* returns NIL if empty. */
int     PopQueue(Queue *Q){ 
  int v;
  if(IsEmptyQueue(Q)) return NIL;
  v = Q->data[Q->get];
  Q->get = (Q->get + 1) % Q->nbuckets;
  Q->nadded--;
  return v;
}


void    ResetQueue(Queue *Q){
  Q->put = Q->get = 0;
  Q->nadded = 0;
}


bool IsEmptyQueue(Queue *Q){ 
  return (Q->nadded==0); 
}


bool IsFullQueue(Queue *Q){ 
  return (Q->nadded==Q->nbuckets); 
}



