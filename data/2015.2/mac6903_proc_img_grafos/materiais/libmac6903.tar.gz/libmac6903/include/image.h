#ifndef _IMAGE_H_
#define _IMAGE_H_

#include "common.h"

typedef struct _image {
  int *val;
  int ncols,nrows;
} Image;


Image  *CreateImage(int ncols,int nrows);
void    DestroyImage(Image **img);
Image  *CloneImage(Image *img);
Image  *ReadImage(char *filename);
void    WriteImage(Image *img, char *filename);

Image  *ConvertToNbits(Image *img, int N);
int     MinimumValue(Image *img);
int     MaximumValue(Image *img);
void    SetImage(Image *img, int value);
bool    ValidPixel(Image *img, int x, int y);

#endif

