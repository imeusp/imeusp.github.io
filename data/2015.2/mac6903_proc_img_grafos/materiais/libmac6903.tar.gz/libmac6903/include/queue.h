
#ifndef _QUEUE_H_
#define _QUEUE_H_

#include "common.h"

/**
  * \brief FIFO Queue with circular and growing features.
*/
typedef struct _queue {
  int *data;
  int get, put;
  int nbuckets;
  int nadded;   //!< Number of elements added.
} Queue;


Queue  *CreateQueue(int nbuckets);
void    DestroyQueue(Queue **Q);
    
void    PushQueue(Queue *Q, int p);

/**
 * @return Returns NIL if empty.
 */
int         PopQueue(Queue *Q);

void        ResetQueue(Queue *Q);
bool        IsEmptyQueue(Queue *Q);
bool        IsFullQueue(Queue *Q);


#endif


