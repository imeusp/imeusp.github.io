#ifndef _CIMAGE_H_
#define _CIMAGE_H_

#include "image.h"

typedef struct cimage {
  Image *C[3];
} CImage;


CImage *CreateCImage(int ncols, int nrows);
void    DestroyCImage(CImage **cimg);
CImage *CloneCImage(CImage *cimg);
CImage *ReadCImage(char *filename);
void    WriteCImage(CImage *cimg, char *filename);
void    SetCImage(CImage *cimg, int r, int g, int b);

CImage *ColorizeLabel(Image *label);

#endif

