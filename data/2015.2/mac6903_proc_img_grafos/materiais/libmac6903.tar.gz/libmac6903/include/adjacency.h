#ifndef _ADJACENCY_H_
#define _ADJACENCY_H_

#include "common.h"

typedef struct _adjrel {
  int *dx;
  int *dy;
  int n;
} AdjRel;


AdjRel *CreateAdjRel(int n);
void    DestroyAdjRel(AdjRel **A);
AdjRel *CloneAdjRel(AdjRel *A);

AdjRel *Neighborhood_4(); /* 4-neighborhood */
AdjRel *Neighborhood_8(); /* 8-neighborhood */

AdjRel *Circular(float r);
AdjRel *Box(int ncols, int nrows);

#endif

