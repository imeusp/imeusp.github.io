
#ifndef _MORPHOLOGY_H_
#define _MORPHOLOGY_H_

#include "image.h"
#include "adjacency.h"

Image *Dilate(Image *img, AdjRel *A);
Image *Erode(Image *img, AdjRel *A);

Image *MorphGrad(Image *img, AdjRel *A);


#endif
