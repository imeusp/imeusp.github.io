
#include "common.h"
#include "image.h"
#include "cimage.h"
#include "adjacency.h"
#include "queue.h"
#include "gpqueue_by_Falcao.h"
#include "morphology.h"


void SupRec_Watershed(AdjRel *A, 
		      Image *I, Image *J, 
		      Image *L, Image *V){
  GQueue *Q;
  Image *P;
  int Jmax,n,p,q,tmp,i,l = 1;
  int xp,yp,xq,yq;

  Jmax = MaximumValue(J);
  n = I->ncols*I->nrows;
  P = CreateImage(I->ncols, I->nrows);
  Q = CreateGQueue(Jmax+2, n, V->val);
  SetImage(L, 0);
  for(p = 0; p < n; p++){
    P->val[p] = NIL;
    V->val[p] = J->val[p] + 1;
    InsertGQueue(&Q, p);
  }

  while(!EmptyGQueue(Q)){
    p = RemoveGQueue(Q);

    if(P->val[p]==NIL){
      V->val[p] = J->val[p];
      L->val[p] = l;
      l++;
    }

    xp = p%I->ncols;
    yp = p/I->ncols;
    for(i = 1; i < A->n; i++){
      xq = xp + A->dx[i];
      yq = yp + A->dy[i];
      if(ValidPixel(I, xq, yq)){
	q = xq + yq*I->ncols;
	if(Q->L.elem[q].color != BLACK){
	  tmp = MAX(V->val[p], I->val[q]);

	  if(tmp < V->val[q]){
	    if(Q->L.elem[q].color == GRAY)
	      RemoveGQueueElem(Q, q);
	    L->val[q] = L->val[p];
	    P->val[q] = p;
	    V->val[q] = tmp;
	    InsertGQueue(&Q, q);	    
	  }
	}
      }
    }
  }
  DestroyImage(&P);
  DestroyGQueue(&Q);
}


int main(){
  CImage *cL;
  Image *O,*I,*J,*L,*V;
  AdjRel *A;
  int h,p,n;

  A = Circular(1.5);
  printf("Entre com o valor de h: ");
  scanf("%d",&h);
  O = ReadImage("./dat/knee.pgm");
  I = MorphGrad(O, A);
  J = CreateImage(I->ncols, I->nrows);
  L = CreateImage(I->ncols, I->nrows);
  V = CreateImage(I->ncols, I->nrows);
  n = O->ncols*O->nrows;
  for(p = 0; p < n; p++){
    J->val[p] = I->val[p] + h;
  }
  SupRec_Watershed(A, I, J, L, V);

  cL = ColorizeLabel(L);
  WriteCImage(cL, "cL.ppm");
  DestroyCImage(&cL);

  WriteImage(I, "I.pgm");

  WriteImage(V, "V.pgm");

  DestroyImage(&O);
  DestroyImage(&I);
  DestroyImage(&J);
  DestroyImage(&L);
  DestroyImage(&V);
  DestroyAdjRel(&A);

  return 0;
}

