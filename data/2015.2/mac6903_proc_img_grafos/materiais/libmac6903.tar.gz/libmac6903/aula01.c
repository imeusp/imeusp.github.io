
#include "common.h"
#include "image.h"
#include "cimage.h"
#include "adjacency.h"
#include "queue.h"


Image *ConnectedComponents(Image *bin, AdjRel *A){
  Queue  *Q;
  Image *label;
  int n,p,q,r,i,l = 1;
  int xq,yq,xr,yr;

  n = bin->ncols*bin->nrows;
  Q = CreateQueue(n);
  label = CreateImage(bin->ncols, bin->nrows);
  SetImage(label, 0);

  for(p = 0; p < n; p++){
    if(label->val[p] == 0){
      label->val[p] = l;
      PushQueue(Q, p);

      while(!IsEmptyQueue(Q)){
	q = PopQueue(Q);
	xq = q%bin->ncols;
	yq = q/bin->ncols;
	for(i = 1; i < A->n; i++){
	  xr = xq + A->dx[i];
	  yr = yq + A->dy[i];
	  if(ValidPixel(bin, xr, yr)){
	    r = xr + yr*bin->ncols;
	    if(label->val[r] == 0 &&
	       bin->val[r] == bin->val[q]){
	      label->val[r] = l;
	      PushQueue(Q, r);
	    }
	  }
	}
      }
      l++;
    }
  }
  DestroyQueue(&Q);
  return label;
}


Image *KConnectedComponents(Image *img, AdjRel *A, int K){
  Queue  *Q;
  Image *label;
  int n,p,q,r,i,l = 1;
  int xq,yq,xr,yr,wqr;

  n = img->ncols*img->nrows;
  Q = CreateQueue(n);
  label = CreateImage(img->ncols, img->nrows);
  SetImage(label, 0);

  for(p = 0; p < n; p++){
    if(label->val[p] == 0){
      label->val[p] = l;
      PushQueue(Q, p);

      while(!IsEmptyQueue(Q)){
	q = PopQueue(Q);
	xq = q%img->ncols;
	yq = q/img->ncols;
	for(i = 1; i < A->n; i++){
	  xr = xq + A->dx[i];
	  yr = yq + A->dy[i];
	  if(ValidPixel(img, xr, yr)){
	    r = xr + yr*img->ncols;
	    wqr = abs(img->val[r] - img->val[q]);
	    if(label->val[r] == 0 && wqr <= K){
	      label->val[r] = l;
	      PushQueue(Q, r);
	    }
	  }
	}
      }
      l++;
    }
  }
  DestroyQueue(&Q);
  return label;
}

void Union(Image *R, int *rp, int rq, Image *S, Image *N){
  if(N->val[*rp] >= N->val[rq]){
    N->val[*rp] = N->val[*rp] + N->val[rq];
    S->val[*rp] = S->val[*rp] + S->val[rq];
    R->val[rq] = *rp;
  }
  else{
    N->val[rq] = N->val[rq] + N->val[*rp];
    S->val[rq] = S->val[rq] + S->val[*rp];
    R->val[*rp] = rq;
    *rp = rq;
  }
}

/* Devolve o representante de p */
int Find(Image *R, int p){
  if(R->val[p] == p)
    return p;
  else{
    R->val[p] = Find(R, R->val[p]);
    return R->val[p];
  }
}


Image *LabelingByDisjointSets(Image *img, AdjRel *A, int T){
  Image *R; /* imagem de representantes */
  Image *S; /* soma dos brilhos dos pixels do componente */
  Image *N; /* numero de pixels do seu componente */
  Image *L;
  int p,q,n,rp,rq,i,l = 1;
  int xp,yp,xq,yq,diff;

  n = img->ncols*img->nrows;
  R = CreateImage(img->ncols, img->nrows);
  S = CreateImage(img->ncols, img->nrows);
  N = CreateImage(img->ncols, img->nrows);
  L = CreateImage(img->ncols, img->nrows);

  for(p = 0; p < n; p++){
    R->val[p] = p;
    S->val[p] = img->val[p];
    N->val[p] = 1;
  }
  for(p = 0; p < n; p++){
    rp = Find(R, p);
    xp = p%img->ncols;
    yp = p/img->ncols;
    for(i = 1; i < A->n; i++){
      xq = xp + A->dx[i];
      yq = yp + A->dy[i];
      if(ValidPixel(img, xq, yq)){
	q = xq + yq*img->ncols;
	rq = Find(R, q);
	if(rq != rp){
	  diff = S->val[rp]/N->val[rp] - S->val[rq]/N->val[rq];
	  if(abs(diff) <= T)
	    Union(R, &rp, rq, S, N);
	}
      }
    }
  }
  for(p = 0; p < n; p++){
    R->val[p] = Find(R, p);
    if(R->val[p] == p){
      L->val[p] = l;
      l++;
    }
  }
  for(p = 0; p < n; p++){
    L->val[p] = L->val[R->val[p]];
  }
  DestroyImage(&R);
  DestroyImage(&S);
  DestroyImage(&N);
  return L;
}


int main(){
  CImage *clabel;
  Image *img,*bin,*label;
  AdjRel *A;

  A = Circular(1.5);

  bin = ReadImage("./dat/tools.pgm");
  label = ConnectedComponents(bin, A);
  clabel = ColorizeLabel(label);
  WriteCImage(clabel, "clabel1.ppm");
  DestroyCImage(&clabel);
  DestroyImage(&label);
  DestroyImage(&bin);

  img = ReadImage("./dat/knee.pgm");
  label = KConnectedComponents(img, A, 2); //4
  clabel = ColorizeLabel(label);
  WriteCImage(clabel, "clabel2.ppm");
  DestroyCImage(&clabel);
  DestroyImage(&label);

  label = LabelingByDisjointSets(img, A, 5);
  clabel = ColorizeLabel(label);
  WriteCImage(clabel, "clabel3.ppm");
  DestroyCImage(&clabel);
  DestroyImage(&label);

  DestroyImage(&img);
  DestroyAdjRel(&A);
  return 0;
}

